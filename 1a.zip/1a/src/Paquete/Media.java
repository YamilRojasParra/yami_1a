
 //* @author yamil
 
public class Media {

    public Media() {
    }

    /**
     * @param dataList 
     * @param n
     */
    public double getMedia(String[] dataList, int n) {

        double suma=0;

        for(int i=0; i<dataList.length; i++){
            System.out.println(dataList[i]);
        }
            for (int x = 0; x<dataList.length; x++){
                suma = suma + Double.parseDouble(dataList[x]);
            }

            double promedio = suma / dataList.length;
        return promedio;
    }
}
