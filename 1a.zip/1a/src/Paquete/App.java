/**
 * @author yamil
 */
public class App {

    public App() {
        
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("Bienvenido");
        Logic mlogic = new Logic();
        mlogic.logic1a();
    }

}
