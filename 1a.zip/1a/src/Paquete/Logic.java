/**
 * @author yamil
 */

public class Logic {

    public Logic() {
    }

    private int n;
    private String data;
    private String[] arrData;
    private double media;
    public double desv;

    public void logic1a() {
        
        Input myInput = new Input();
        Output myOut = new Output();
        
		Data myData = new Data();
		Media myMedia = new Media();
		DesvEst myDesv = new DesvEst();

        data = myInput.readData("C:\\Users\\yamil\\Documents\\3.txt");
        System.out.println("data :  " + data);

		arrData = myData.saveData(data);
        n = arrData.length;
        System.out.println("n :  " + n);

        media = myMedia.getMedia(arrData, n);
        System.out.println("media :  " + media);

		desv = myDesv.getDesvEstd(arrData, media, n);
        System.out.println("desv std :  " + desv);

        myOut.writeData("C:\\Users\\yamil\\Documents\\out1.txt", "Media = " + media + " Desv. = " + desv);

    }

}
